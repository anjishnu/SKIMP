import java.awt.*;
import java.net.URL;

/**
 * A class that represents a picture.  This class inherits from SimplePicture
 *     and allows the student to add functionality and picture effects. 
 *
 * @author Barb Ericson (ericson@cc.gatech.edu)
 *     (Copyright Georgia Institute of Technology 2004)
 * @author Modified by Colleen Lewis (colleenl@berkeley.edu),
 *     Jonathan Kotker (jo_ko_berkeley@berkeley.edu),
 *     Kaushik Iyer (kiyer@berkeley.edu), George Wang (georgewang@berkeley.edu),
 *     and David Zeng (davidzeng@berkeley.edu), for use in CS61BL, the data
 *     structures course at University of California, Berkeley.
 */
public class Picture extends SimplePicture
{

    /////////////////////////// Static Variables //////////////////////////////

    // Different axes available to flip a picture.
    public static final int HORIZONTAL = 1;
    public static final int VERTICAL = 2;
    public static final int FORWARD_DIAGONAL = 3;
    public static final int BACKWARD_DIAGONAL = 4;

    // Different Picture objects for the bitmaps used in ASCII art conversion.
    private static Picture BMP_AMPERSAND;
    private static Picture BMP_APOSTROPHE;
    private static Picture BMP_AT;
    private static Picture BMP_BAR;
    private static Picture BMP_COLON;
    private static Picture BMP_DOLLAR;
    private static Picture BMP_DOT;
    private static Picture BMP_EXCLAMATION;
    private static Picture BMP_GRAVE;
    private static Picture BMP_HASH;
    private static Picture BMP_PERCENT;
    private static Picture BMP_SEMICOLON;
    private static Picture BMP_SPACE;    

    //////////////////////////// Constructors /////////////////////////////////

    /**
     * A constructor that takes no arguments.
     */
    public Picture () {
        super(); 
    }

    /**
     * Creates a Picture from the file name provided.
     *
     * @param fileName The name of the file to create the picture from.
     */
    public Picture(String fileName) {
        // Let the parent class handle this fileName.
        super(fileName);
    }

    /**
     * Creates a Picture from the width and height provided.
     *
     * @param width the width of the desired picture.
     * @param height the height of the desired picture.
     */
    public Picture(int width, int height) {
        // Let the parent class handle this width and height.
        super(width, height);
    }

    /**
     * Creates a copy of the Picture provided.
     *
     * @param pictureToCopy Picture to be copied.
     */
    public Picture(Picture pictureToCopy) {
        // Let the parent class do the copying.
        super(pictureToCopy);
    }

    /**
     * Creates a copy of the SimplePicture provided.
     *
     * @param pictureToCopy SimplePicture to be copied.
     */
    public Picture(SimplePicture pictureToCopy) {
        // Let the parent class do the copying.
        super(pictureToCopy);
    }

    /////////////////////////////// Methods ///////////////////////////////////

    /**
     * @return A string with information about the picture, such as
     *     filename, height, and width.
     */
    public String toString() {
        String output = "Picture, filename = " + this.getFileName() + "," +
        " height = " + this.getHeight() + ", width = " + this.getWidth();
        return output;
    }

    /////////////////////// PROJECT 1 BEGINS HERE /////////////////////////////

    /* Each of the methods below is constructive: in other words, each of
     *     the methods below generates a new Picture, without permanently
     *     modifying the original Picture. */

    //////////////////////////////// Level 1 //////////////////////////////////

    /**
     * Converts the Picture into grayscale. Since any variation of gray
     *     is obtained by setting the red, green, and blue components to the same
     *     value, a Picture can be converted into its grayscale component
     *     by setting the red, green, and blue components of each pixel in the
     *     new picture to the same value: the average of the red, green, and blue
     *     components of the same pixel in the original.
     *
     * @return A new Picture that is the grayscale version of this Picture.
     */
    public Picture grayscale() {
        Picture newPicture = new Picture(this);

        int pictureHeight = this.getHeight();
        int pictureWidth = this.getWidth();

        for(int x = 0; x < pictureWidth; x++) {
            for(int y = 0; y < pictureHeight; y++) {
                newPicture.setPixelToGray(x, y);
            }
        }
        return newPicture;
    }

    /**
     * Helper method for grayscale() to set a pixel at (x, y) to be gray.
     *
     * @param x The x-coordinate of the pixel to be set to gray.
     * @param y The y-coordinate of the pixel to be set to gray.
     */
    private void setPixelToGray(int x, int y) {
        Pixel currentPixel = this.getPixel(x, y);
        int average = currentPixel.getAverage();
        currentPixel.setRed(average);
        currentPixel.setGreen(average);
        currentPixel.setBlue(average);       
    }

    /**
     * Test method for setPixelToGray. This method is called by
     * the JUnit file through the public method Picture.helpersWork().
     */
    private static boolean setPixelToGrayWorks()
    {
        Picture bg           = Picture.loadPicture("Creek.bmp");
        Pixel focalPixel     = bg.getPixel(10, 10);
        bg.setPixelToGray(10, 10);
        int goalColor        = (int) focalPixel.getAverage();
        int originalAlpha    = focalPixel.getColor().getAlpha();
        boolean redCorrect   = focalPixel.getRed() == goalColor;
        boolean greenCorrect = focalPixel.getGreen() == goalColor;
        boolean blueCorrect  = focalPixel.getBlue() == goalColor;
        boolean alphaCorrect = focalPixel.getAlpha() == originalAlpha;
        return redCorrect && greenCorrect && blueCorrect && alphaCorrect;
    }

    /**
     * This method provide JUnit access to the testing methods written
     * within Picture.java
     */
    public static boolean helpersWork()
    {
        if (!Picture.setPixelToGrayWorks())
        {
            return false;
        }

        // You could put other tests here..

        return true;
    }

    /**
     * Converts the Picture into its photonegative version. The photonegative
     *     version of an image is obtained by setting each of the red, green,
     *     and blue components of every pixel to a value that is 255 minus their
     *     current values.
     *
     * @return A new Picture that is the photonegative version of this Picture.
     */
    public Picture negate() {
        Picture negativePicture = new Picture(this);
        int picHeight = negativePicture.getHeight(); //dependent on the Picture(this) constructor -- if negativePicture's height is different from thisPicture, we'll have a problem
        int picWidth = negativePicture.getWidth(); //dependent on the Picture(this) constructor -- if negativePicture's width is different from thisPicture, we'll have a problem
        for (int x=0;x<picWidth;x++) {
            for(int y=0;y<picHeight;y++) {
                negativePicture.setPixelToNegative(x, y);
            }
        }
       
        return negativePicture;
    }
    /**
     * Helper method for negate(). Picks pixel at current x,y from negate's double "for" loop.
     * Replaces pixel's values with photonegated values (255-hue value).
     *
     * @param x
     * @param y
     */
    public void setPixelToNegative(int x, int y) {
        Pixel currentPixel = this.getPixel(x,y);
        int currentRed = currentPixel.getRed();
        int currentBlue = currentPixel.getBlue();
        int currentGreen = currentPixel.getGreen();
        currentPixel.setRed(255-currentRed);
        currentPixel.setBlue(255-currentBlue);
        currentPixel.setGreen(255-currentGreen);
    }
   
    /**
     * Creates an image that is lighter than the original image. The range of
     * each color component should be between 0 and 255 in the new image. The
     * alpha value should not be changed.
     *
     * @return A new Picture that has every color value of the Picture increased
     *         by the lightenAmount.
     */
    public Picture lighten(int lightenAmount) {
        Picture lightenedPicture = new Picture(this);
        int pictureHeight = lightenedPicture.getHeight();
        int pictureWidth = lightenedPicture.getWidth();
        for (int x=0;x<pictureWidth;x++){
            for(int y=0;y<pictureHeight;y++){
                lightenedPicture.setPixelToLighter(x, y, lightenAmount);
            }
        }
        return lightenedPicture;
    }
     /**
      * Helper method for lighten(). Finds Pixel at the current x,y values in to-be-returned lightenedPicture.
      * Increases values of all hues by desired lightenAmount.
      * If lightenAmount increase causes hue value to become >255, hue value is set to 255.
      *
      * @param x
      * @param y
      * @param lightenAmount
      */
    public void setPixelToLighter(int x, int y, int lightenAmount) {
        Pixel currentPixel = this.getPixel(x, y);
        int currentRed = currentPixel.getRed();
        int currentGreen = currentPixel.getGreen();
        int currentBlue = currentPixel.getBlue();
        if (currentRed+lightenAmount<=255){
            currentPixel.setRed(currentRed+lightenAmount);
        } else {
            currentPixel.setRed(255);
        }
        if (currentBlue+lightenAmount<=255){
            currentPixel.setBlue(currentBlue+lightenAmount);
        } else {
            currentPixel.setBlue(255);
        }
        if (currentGreen+lightenAmount<=255){
            currentPixel.setGreen(currentGreen+lightenAmount);
        } else {
            currentPixel.setGreen(255);
        }
    }

    /**
     * Creates an image that is darker than the original image.The range of
     * each color component should be between 0 and 255 in the new image. The
     * alpha value should not be changed.
     *
     * @return A new Picture that has every color value of the Picture decreased
     *         by the darkenenAmount.
     */
    public Picture darken(int darkenAmount) {
        Picture darkenedPicture = new Picture(this);
        int pictureHeight = this.getHeight();
        int pictureWidth = this.getWidth();
       
        for(int x=0;x<pictureWidth;x++) {
            for(int y=0;y<pictureHeight;y++) {
                darkenedPicture.setPixelToDarker(x,y,darkenAmount);
            }
        }
        return darkenedPicture;
    }
    /**
     * Helper method for darken(). Takes in x,y values of pixel to be darkened.
     * If pixel's hue values - darkenAmount will not be <0, set each hue value to value-darkenAmount.
     * Else, set hue value to  0.
     * @param x
     * @param y
     * @param darkenAmount
     */
    public void setPixelToDarker(int x, int y, int darkenAmount) {
        Pixel currentPixel = this.getPixel(x, y);
        int currentRed = currentPixel.getRed();
        int currentGreen = currentPixel.getGreen();
        int currentBlue = currentPixel.getBlue();
        if(currentRed-darkenAmount>=0){
            currentPixel.setRed(currentRed-darkenAmount);
        } else {
            currentPixel.setRed(0);
        }
        if(currentGreen-darkenAmount>=0){
            currentPixel.setGreen(currentGreen-darkenAmount);
        } else {
            currentPixel.setGreen(0);
        }
        if(currentBlue-darkenAmount>=0){
            currentPixel.setBlue(currentBlue-darkenAmount);
        } else {
            currentPixel.setBlue(0);
        }
           
    }
    /**
     * Creates an image where the blue value has been increased by amount.The range of
     * each color component should be between 0 and 255 in the new image. The
     * alpha value should not be changed.
     *
     * @return A new Picture that has every blue value of the Picture increased
     *         by amount.
     */
    public Picture addBlue(int amount) {
        Picture bluePicture = new Picture(this);
        int pictureHeight = bluePicture.getHeight();
        int pictureWidth = bluePicture.getWidth();
        for(int x=0;x<pictureWidth;x++){
            for(int y=0;y<pictureHeight;y++){
                bluePicture.setPixelToBluer(x,y,amount);
            }
        }
        return bluePicture;
    }
   
    /**
     * Helper method to addBlue(). Takes in x,y values of pixel to be blue-hued and blue amount.
     * If sum of current blue hue value and blue amount is <=255, pixel's blue hue value is changed.
     * Else the pixel's blue hue value is set to 255.
     * @param x
     * @param y
     * @param amount
     */
    public void setPixelToBluer(int x,int y,int amount) {
        Pixel currentPixel = this.getPixel(x, y);
        int currentBlue = currentPixel.getBlue();
        if(currentBlue+amount<=255){
            currentPixel.setBlue(currentBlue+amount);
        } else {
            currentPixel.setBlue(255);
        }
    }
    /**
     * Creates an image where the red value has been increased by amount. The range of
     * each color component should be between 0 and 255 in the new image. The
     * alpha value should not be changed.
     *
     * @return A new Picture that has every red value of the Picture increased
     *         by amount.
     */
    public Picture addRed(int amount) {
        Picture redPicture = new Picture(this);
        int pictureHeight = redPicture.getHeight();
        int pictureWidth = redPicture.getWidth();
        for (int x=0;x<pictureWidth;x++){
            for(int y=0; y<pictureHeight;y++){
                redPicture.setPixelToRedder(x,y,amount);
            }
        }
        return redPicture;
    }
    /**
     * Helper method for addRed(). Takes x,y value of pixel to be modified, and the red-increase amount.
     * If the sum of the pixel's red hue value and red-increase amount is <= 255, the pixel's hue value is changed to the sum.
     * Else the pixel's hue value is set to 255.
     * @param x
     * @param y
     * @param amount
     */
    public void setPixelToRedder(int x,int y,int amount) {
        Pixel currentPixel = this.getPixel(x, y);
        int currentRed = currentPixel.getRed();
        if (currentRed+amount<=255){
            currentPixel.setRed(currentRed+amount);
        } else{
            currentPixel.setRed(255);
        }
    }
   
    /**
     * Creates an image where the green value has been increased by amount. The range of
     * each color component should be between 0 and 255 in the new image. The
     * alpha value should not be changed.
     *
     * @return A new Picture that has every green value of the Picture increased
     *         by amount.
     */
    public Picture addGreen(int amount) {
        Picture greenPicture = new Picture(this);
        int pictureHeight = greenPicture.getHeight();
        int pictureWidth = greenPicture.getWidth();
        for (int x=0;x<pictureWidth;x++){
            for(int y=0;y<pictureHeight;y++){
                greenPicture.setPixelToGreener(x,y,amount);
            }
        }
        return greenPicture;
    }
   
    public void setPixelToGreener(int x,int y, int amount){
        Pixel currentPixel = this.getPixel(x,y);
        int currentGreen = currentPixel.getGreen();
        if(currentGreen+amount<=255){
            currentPixel.setGreen(currentGreen+amount);
        }else{
            currentPixel.setGreen(255);
        }
    }
   
    /**
     * @param x x-coordinate of the pixel currently selected.
     * @param y y-coordinate of the pixel currently selected.
     * @param background Picture to use as the background.
     * @param threshold Threshold within which to replace pixels.
     *
     * @return A new Picture where all the pixels in the original Picture,
     *     which differ from the currently selected pixel within the provided
     *     threshold (in terms of color distance), are replaced with the
     *     corresponding pixels in the background picture provided.
     *
     *     If the two Pictures are of different dimensions, the new Picture will
     *     have length equal to the smallest of the two Pictures being combined,
     *     and height equal to the smallest of the two Pictures being combined.
     *     In this case, the Pictures are combined as if they were aligned at
     *     the top left corner (0, 0).
     */
    public Picture chromaKey(int xRef, int yRef, Picture background, int threshold) {
        Picture chromaPicture = new Picture(Math.min(this.getWidth(), background.getWidth()),Math.min(this.getHeight(), background.getHeight()));
        Picture currentPicture = this;
        int pictureHeight = chromaPicture.getHeight();
        int pictureWidth = chromaPicture.getWidth();
        for(int x=0;x<pictureWidth;x++){
            for(int y=0;y<pictureHeight;y++){
                if(currentPicture.getPixel(xRef, yRef).colorDistance(currentPicture.getPixel(x,y).getColor())<=threshold){
                    chromaPicture.getPixel(x,y).setColor(background.getPixel(x, y).getColor());
                } else {
                    chromaPicture.getPixel(x,y).setColor(currentPicture.getPixel(x, y).getColor());
                }
            }
        }
        return chromaPicture;
    }

    //////////////////////////////// Level 2 //////////////////////////////////

    /**
     * Rotates this Picture by the integer multiple of 90 degrees provided.
     *     If the number of rotations provided is positive, then the picture
     *     is rotated clockwise; else, the picture is rotated counterclockwise.
     *     Multiples of four rotations (including zero) correspond to no
     *     rotation at all.
     *
     * @param rotations The number of 90-degree rotations to rotate this
     *     image by.
     *
     * @return A new Picture that is the rotated version of this Picture.
     */
    public Picture rotate(int rotations) {
        int newHeight = this.getHeight();
        int newWidth = this.getWidth();
        //Counter-clockwise fixer: if rotations are <0, the rotation will be in multiples of -90 degrees. This can be viewed as starting from 3 rotations and working back toward 0. This code accommodates such thinking by setting any -90x degree rotation to be a 270 degree rotation, and any -270x degree rotation to be a 90 degree rotation.
        if (rotations<0){
            if(rotations%4 == 1){
                rotations = 3;
            }
            if(rotations%4 == 3){
                rotations = 1;
            }
        }
        //Aspect ratio fixer: if rotation is 90/270 degree, change the dimensions of return Picture. For example, a 5Wx10H Picture rotated 90 degrees must return a 10Wx5H Picture.
        if(rotations%4 == 3 || rotations%4 == 1){
            int temp= newWidth;
            newWidth = newHeight;
            newHeight = temp;
        }
        //rotator
        Picture rotatedPicture = new Picture(newWidth, newHeight);
        for(int y=0;y<this.getHeight();y++){
           for(int x=0;x<this.getWidth();x++){
               if (rotations%4==1){
            	   Pixel tempPix = rotatedPicture.getPixel(newWidth-y-1, x); //Access the rotated picture's pixel we are interested in changing; for one rotation, we look at the right-most, top-most value (at newWidth-1) moving down (increasing x, to shift pixel location down) and then left (at every y increment -- newWidth-y-1) until all pixels are accessed
            	   tempPix.setColor(this.getPixel(x, y).getColor()); // Set the accessed pixel's color to the color of the pixel we are copying.
               }
               if(rotations%4==2){
            	   Pixel tempPix = rotatedPicture.getPixel(newWidth-x-1,newHeight-y-1); // For two rotations, we start at the bottom-right-most corner. As x increases, our pixel of interest moves left until we reach the left margin. Then, y is incremented, x is reset, and we start copying one line up on the right side again.
            	   tempPix.setColor(this.getPixel(x,y).getColor()); // Set the accessed pixel's color to the color of the pixel we are copying.
               }
               if(rotations%4==3){
            	   Pixel tempPix = rotatedPicture.getPixel(y, newHeight-x-1); // For a 270 degree rotation, we start at the bottom-left-most corner. As x increases, our pixel of interest shifts up until we reach the top margin. Then y is incremented, x is reset to the bottom, and we start copying the line on the right.
            	   tempPix.setColor(this.getPixel(x,y).getColor());
               }
               if(rotations%4==0){
            	   Pixel tempPix = rotatedPicture.getPixel(x,y);
            	   tempPix.setColor(this.getPixel(x,y).getColor());
               }
            }
           
        }
        return rotatedPicture;
    }

    /**
     * Flips this Picture about the given axis. The axis can be one of
     *     four static integer constants:
     *
     *     (a) Picture.HORIZONTAL: The picture should be flipped about
     *         a horizontal axis passing through the center of the picture.
     *     (b) Picture.VERTICAL: The picture should be flipped about
     *         a vertical axis passing through the center of the picture.
     *     (c) Picture.FORWARD_DIAGONAL: The picture should be flipped about
     *         an axis that passes through the north-east and south-west
     *         corners of the picture.
     *     (d) Picture.BACKWARD_DIAGONAL: The picture should be flipped about
     *         an axis that passes through the north-west and south-east
     *         corners of the picture.
     *
     * @param axis Axis about which to flip the Picture provided.
     *
     * @return A new Picture flipped about the axis provided.
     */
    public Picture flip(int axis) {
        Picture flipPic = new Picture(this);
    	if (axis == 1){ //flips about a Horizontal axis at mid-height. Copies pixels starting from top-left of original picture (incrementing x to extent of width, then y) to the pixel with converse y value (read: Height minus current y value) in flipPic. For example, a 5Wx10H this.picture would have its 0,0 pixel copied to 0,9. Then, its 1,0 pixel copied to 1,9. Final copy would be 4,9 this.pixel copied to 0,0.
    		for(int y=0;y<this.getHeight();y++){
    			for(int x=0;x<this.getWidth();x++){
    				Pixel tempPix = flipPic.getPixel(x, flipPic.getHeight()-y-1);
    				tempPix.setColor(this.getPixel(x, y).getColor());
    			}
    		}
        }
    	if (axis == 2){//Flips about a vertical axis at mid-width. Copies pixels starting from top-left of original picture (incrementing x to extent of width, then y) to the pixel with converse x value (read: Width minus current x value) in flipPic. For example, a 5Wx10H this.picture would have its 0,0 pixel copied to 4,0. Then its 1,0 pixel copied to 3,0. Final copy would be 4,9 this.pixel copied to 0,9.
    		for(int y=0;y<this.getHeight();y++){
    			for(int x=0;x<this.getWidth();x++){
    				Pixel tempPix = flipPic.getPixel(flipPic.getWidth()-x-1, y);
    				tempPix.setColor(this.getPixel(x,y).getColor());
    			}
    		}
    	}
    	if (axis == 3){//flips about an axis extending from the south-west to the north-east corner. Rotates the picture 90 degrees, then flips across a horizontal axis. This produces the same result as flipping across a forward-diagonal axis.
    		flipPic = this.rotate(1);
    		flipPic = flipPic.flip(HORIZONTAL);
    		}
    	if(axis == 4){//flips about an axis extending from the north-west to the south-east corner. Rotates the picture 270 degrees, then flips across a horizontal axis. This produces the same result as flipping across a backward-diagonal axis.
    		flipPic = this.rotate(3);
    		flipPic = flipPic.flip(HORIZONTAL);
    		}
    	return flipPic;
    }

    /**
     * @param threshold
     *            Threshold to use to determine the presence of edges.
     *
     * @return A new Picture that contains only the edges of this Picture. For
     *         each pixel, we separately consider the color distance between
     *         that pixel and the one pixel to its left, and also the color
     *         distance between that pixel and the one pixel to the north, where
     *         applicable. As an example, we would compare the pixel at (3, 4)
     *         with the pixels at (3, 3) and the pixels at (2, 4). Also, since
     *         the pixel at (0, 4) only has a pixel to its north, we would only
     *         compare it to that pixel. If either of the color distances is
     *         larger than the provided color threshold, it is set to black
     *         (with an alpha of 255); otherwise, the pixel is set to white
     *         (with an alpha of 255). The pixel at (0, 0) will always be set to
     *         white.
     */
    public Picture showEdges(int threshold) {
        Picture edgePic = new Picture(this.getWidth(),this.getHeight());
    	for (int y=0;y<this.getHeight();y++){
    		for(int x=0;x<this.getWidth();x++){
    			if(x==0){
    				if(y==0){
    					edgePic.getPixel(x,y).setColor(Color.white);
    				} else{
    					if((int) this.getPixel(x, y).colorDistance(this.getPixel(x,y-1).getColor())>threshold){
    						edgePic.getPixel(x,y).setColor(Color.black);
    						}
    					}
    				} 
    			else{
    				if(y==0){
    					if((int) this.getPixel(x,y).colorDistance(this.getPixel(x-1,y).getColor())>threshold){
    						edgePic.getPixel(x,y).setColor(Color.black);
    					}else{
    						edgePic.getPixel(x,y).setColor(Color.white);
    					}
    				} else {
    					if((int) this.getPixel(x,y).colorDistance(this.getPixel(x-1,y).getColor())>threshold || (int) this.getPixel(x,y).colorDistance(this.getPixel(x,y-1).getColor())>threshold){
    						edgePic.getPixel(x,y).setColor(Color.black);
    					}
    				
    				}
    			
    			}
    		}
    	}
        return edgePic;
    }

    //////////////////////////////// Level 3 //////////////////////////////////

    /**
     * @return A new Picture that is the ASCII art version of this Picture. To
     *         implement this, the Picture is first converted into its grayscale
     *         equivalent. Then, starting from the top left, the average color
     *         of every chunk of 10 pixels wide by 20 pixels tall is computed.
     *         Based on the average value obtained, this chunk will be replaced
     *         by the corresponding ASCII character specified by the table
     *         below.
     *
     *           The ASCII characters to be used are available as Picture objects,
     *            also of size 10 pixels by 20 pixels. The following characters
     *            should be used, depending on the average value obtained:
     *    
     *     0 to 18: # (Picture.BMP_POUND)
     *     19 to 37: @ (Picture.BMP_AT)
     *     38 to 56: & (Picture.BMP_AMPERSAND)
     *     57 to 75: $ (Picture.BMP_DOLLAR)
     *     76 to 94: % (Picture.BMP_PERCENT)
     *     95 to 113: | (Picture.BMP_BAR)
     *     114 to 132: ! (Picture.BMP_EXCLAMATION)
     *     133 to 151: ; (Picture.BMP_SEMICOLON)
     *     152 to 170: : (Picture.BMP_COLON)
     *     171 to 189: ' (Picture.BMP_APOSTROPHE)
     *     190 to 208: ` (Picture.BMP_GRAVE)
     *     209 to 227: . (Picture.BMP_DOT)
     *     228 to 255: (Picture.BMP_SPACE)
     *
     * We provide a getAsciiPic method to obtain the Picture object
     *     corresponding to a character, given any of the static Strings
     *     mentioned above.
     *
     * Note that the resultant Picture should be the exact same size
     *     as the original Picture; this might involve characters being
     *     partially copied to the final Picture.
     */
    public Picture convertToAscii() {
        /* REPLACE THE CODE BELOW WITH YOUR OWN. */
        Picture currentPicture = this.grayscale();
        int pictureHeight = currentPicture.getHeight();
        int pictureWidth = currentPicture.getWidth();
        Picture asciiPicture = new Picture(pictureWidth, pictureHeight);
        int blockWidth = 10;
        int blockHeight = 20;
        
        //loops over every 'block' of size blockWidth*blockHeight
        for(int a =0; a< pictureWidth; a+=blockWidth)
        {
        	for(int b=0; b < pictureHeight; b= b+ blockHeight)
        	{
        		int blockW, blockH;
        		// these two ints are usually the same as blockHeight and blockWidth- but unlike the latter they adapt to edge cases
        		if((pictureWidth-a)<blockWidth)
        			blockW = pictureWidth - a;
        		else
        			blockW = blockWidth;
        		
        		if((pictureHeight-b)<blockHeight)
        			blockH = pictureHeight - b;
        		else
        			blockH = blockHeight;
        		
        		int AvGray =0;
        		// computes average grey-value
        		for(int i =0; i<blockW; i++)
        		{
        			for (int j =0; j<blockH; j++)
        			{
        			AvGray += currentPicture.getPixel(a+i, b+j).getAverage();
        			}
        		}
        		AvGray = AvGray/(blockW*blockH);
        		
        		Picture SmallPic = Picture.getAsciiPic(AvGray);
        		
        		//copies SmallPic into the larger AsciiPic
        		for(int i =0; i<blockW; i++)
        		{
        			for (int j =0; j<blockH; j++)
        			{
        				asciiPicture.setBasicPixel(a+i, b+j, SmallPic.getBasicPixel(i, j));	
        			}
        		}
        	}
        }
        
        return asciiPicture;
   }
    
    

    /**
     * Blurs this Picture. To achieve this, the algorithm takes a pixel, and
     * sets it to the average value of all the pixels in a square of side (2 *
     * blurThreshold) + 1, centered at that pixel. For example, if blurThreshold
     * is 2, and the current pixel is at location (8, 10), then we will consider
     * the pixels in a 5 by 5 square that has corners at pixels (6, 8), (10, 8),
     * (6, 12), and (10, 12). If there are not enough pixels available -- if the
     * pixel is at the edge, for example, or if the threshold is larger than the
     * image -- then the missing pixels are ignored, and the average is taken
     * only of the pixels available.
     *
     * The red, blue, green and alpha values should each be averaged separately.
     *
     * @param blurThreshold
     *            Size of the blurring square around the pixel.
     *
     * @return A new Picture that is the blurred version of this Picture, using
     *         a blurring square of size (2 * threshold) + 1.
     */
    public Picture blur(int blurThreshold) 
    
    {
        /* REPLACE THE CODE BELOW WITH YOUR OWN. */
        Picture currentPicture = this;
        int pictureHeight = currentPicture.getHeight();
        int pictureWidth = currentPicture.getWidth();
        Picture blurryPicture = new Picture(pictureWidth, pictureHeight);
        
        //These loop through every pixel in blurPicture, calculates its value by looping over the equivalent square/rectangle in
        for(int y=0; y<pictureHeight; y++)	
        {for (int x=0; x<pictureWidth; x++){
//        	int x = 0, y = 0;	
        	int startX, startY, endX, endY;
        	
        	
        	//should adaptively change the size of the block from a square to a rectangle or something to accommodate edge cases
        	if((x-blurThreshold)<0)
        		startX=0; 
        	else startX = x-blurThreshold;
        	
        	
        	if((y-blurThreshold)<0)
        		startY=0;
        	else startY = y-blurThreshold;
        	
        	if((x+blurThreshold)>=pictureWidth)
        		{endX=pictureWidth-1;}
        	else 
        		endX = x+blurThreshold;
        	
        	if((y+blurThreshold)>=pictureHeight)
        		endY=pictureHeight-1;
        	else endY = y+blurThreshold;
        	
        	//Sets average values- equal to zero- plan -> add up all the colours in each block and divide them
        	int avGreen = 0, avRed = 0, avBlue = 0, avAlpha=0;
//        	System.out.println("StartX startY" + startX +" "+ startY + "endX endY " + endX +" " + endY);
        	//Loop to sum up all colours values in the blocks
        	for(int i=startY; i<=endY; i++)
        		for(int j=startX; j<=endX; j++)
        		{
        			
        			avGreen+= currentPicture.getPixel(j, i).getGreen();
        			avRed+= currentPicture.getPixel(j, i).getRed();
        			avBlue+= currentPicture.getPixel(j, i).getBlue();
        			avAlpha+= currentPicture.getPixel(j, i).getAlpha();
        			//System.out.println("i, j-" + i + j);
        		}
        	
        	//Calculate no. of pixels in a block
        	int blockSize = (endY-startY+1)*(endX-startX+1);
        	//int blockSize = (endY-startY+1)*(endX-startX+1);
//        	System.out.println("Red "+avRed+ " Green " + avGreen + " Blue "+ avBlue + " Alpha " + avAlpha + " BlockSize " + blockSize);
        	//Divide summed values by the size of the block to get 'average' values
        	avGreen = avGreen/blockSize;
        	avBlue = avBlue/blockSize;
        	avRed = avRed/blockSize;
        	avAlpha = avAlpha/blockSize;
//        	System.out.println("Red "+avRed+ " Green " + avGreen + " Blue "+ avBlue + " Alpha " + avAlpha + " BlockSize " + blockSize);        	
        	//Set pixels in blurryPicture to these average values
        	blurryPicture.getPixel(x, y).setGreen(avGreen);
        	blurryPicture.getPixel(x, y).setBlue(avBlue);
        	blurryPicture.getPixel(x, y).setRed(avRed);
        	blurryPicture.getPixel(x, y).setAlpha(avAlpha);
        	}  	
        }
        
        return blurryPicture;
    }


    /**
     * @param x x-coordinate of the pixel currently selected.
     * @param y y-coordinate of the pixel currently selected.
     * @param threshold Threshold within which to delete pixels.
     * @param newColor New color to color pixels.
     *
     * @return A new Picture where all the pixels connected to the currently
     *     selected pixel, and which differ from the selected pixel within the
     *     provided threshold (in terms of color distance), are colored with
     *     the new color provided.
     */
    
    //idea: iterate out from center and add items to queue, also mark as checked. iterate through all pixels; if unchecked and touching queued pixel, check.
    
    
    public Picture paintBucket(int x, int y, int threshold, Color newColor) 
    {
        /* REPLACE THE CODE BELOW WITH YOUR OWN. */
    	
    	boolean [][] ar = new boolean[this.getWidth()][this.getHeight()]; 
    	Picture Temp = new Picture(this);
    	
    	int count =0;
		while(true){
    	int temp = count;
    	count = 0;
    	ar[x][y]= true;
    	
  
    	
    	for(int a=0; a<this.getWidth(); a++){
    		for(int b=0; b<this.getHeight(); b++)
    		{
    			
    			if (shouldchange(a,b,this,ar,threshold,this.getPixel(x, y).getColor()))
    			{
    				Temp.getPixel(a, b).setColor(newColor);
    				ar[a][b]=true;
    				count ++;
    				//System.out.println("found point");
    			}
    		}
    		}
    	
    	
    	if (temp==count)
    	break;
    
    	
    	}
		
    
		
    	
        return Temp;
    }
    
    public boolean shouldchange(int x, int y, Picture orig, boolean [][]ar, int threshold, Color origColor)
    {
    	int startX = 0, startY=0, endX= 0, endY=0;
    	
    	if((x-1)<0)
    		startX=0; //check
    	else startX = x-1;
    	
    	if((y-1)<0)
    		startY=0; //check
    	else startY = y-1;
    	
    	if((x+1)>orig.getWidth()-1)
    		{endX=orig.getWidth()-1;}
    	else 
    		endX = x+1;
    	
    	if((y+1)>orig.getHeight()-1)
    		endY=orig.getHeight()-1;
    	else endY = y+1;
    	
    	if(((int)orig.getPixel(x, y).colorDistance(origColor))<threshold)
    	{
    		
    		for(int i=startY; i<=endY; i++)
    			for(int j=startX; j<=endX; j++)
    			{
    			if (ar[j][i])
    			    	
    				return true;
    			}
    			}
    	return false; 	
    	}
    	
    	
    	

    ///////////////////////// PROJECT 1 ENDS HERE /////////////////////////////

    public boolean equals(Object obj) {
        if (!(obj instanceof Picture)) {
            return false;
        }

        Picture p = (Picture) obj;
        // Check that the two pictures have the same dimensions.
        if ((p.getWidth() != this.getWidth()) ||
                (p.getHeight() != this.getHeight())) {
            return false;
        }

        // Check each pixel.
        for (int x = 0; x < this.getWidth(); x++) {
            for(int y = 0; y < this.getHeight(); y++) {
                if (!this.getPixel(x, y).equals(p.getPixel(x, y))) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Helper method for loading a picture in the current directory.
     */
    protected static Picture loadPicture(String pictureName) {
        URL url = Picture.class.getResource(pictureName);
        return new Picture(url.getFile().replaceAll("%20", " "));
    }

    /**
     * Helper method for loading the pictures corresponding to each character
     *     for the ASCII art conversion.
     */
    private static Picture getAsciiPic(int grayValue) {
        int asciiIndex = (int) grayValue / 19;

        if (BMP_AMPERSAND == null) {
            BMP_AMPERSAND = Picture.loadPicture("ampersand.bmp");
            BMP_APOSTROPHE = Picture.loadPicture("apostrophe.bmp");
            BMP_AT = Picture.loadPicture("at.bmp");
            BMP_BAR = Picture.loadPicture("bar.bmp");
            BMP_COLON = Picture.loadPicture("colon.bmp");
            BMP_DOLLAR = Picture.loadPicture("dollar.bmp");
            BMP_DOT = Picture.loadPicture("dot.bmp");
            BMP_EXCLAMATION = Picture.loadPicture("exclamation.bmp");
            BMP_GRAVE = Picture.loadPicture("grave.bmp");
            BMP_HASH = Picture.loadPicture("hash.bmp");
            BMP_PERCENT = Picture.loadPicture("percent.bmp");
            BMP_SEMICOLON = Picture.loadPicture("semicolon.bmp");
            BMP_SPACE = Picture.loadPicture("space.bmp");
        }

        switch(asciiIndex) {
        case 0:
            return Picture.BMP_HASH;
        case 1:
            return Picture.BMP_AT;
        case 2:
            return Picture.BMP_AMPERSAND;
        case 3:
            return Picture.BMP_DOLLAR;
        case 4:
            return Picture.BMP_PERCENT;
        case 5:
            return Picture.BMP_BAR;
        case 6:
            return Picture.BMP_EXCLAMATION;
        case 7:
            return Picture.BMP_SEMICOLON;
        case 8:
            return Picture.BMP_COLON;
        case 9:
            return Picture.BMP_APOSTROPHE;
        case 10:
            return Picture.BMP_GRAVE;
        case 11:
            return Picture.BMP_DOT;
        default:
            return Picture.BMP_SPACE;
        }
    }

    public static void main(String[] args) {
        Picture initialPicture = new Picture(
                FileChooser.pickAFile(FileChooser.OPEN));
        initialPicture.explore();
    }

} // End of Picture class

